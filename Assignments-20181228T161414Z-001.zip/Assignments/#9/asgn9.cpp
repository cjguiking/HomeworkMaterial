// Ceejay Guiking
// Assignment 9
// CS 302 - 1003
//
// This program implements the use of heaps using a priority queue.
// 
// This program will schedule airfract to the gates, where time is
// measured in minutes, and Flight arrivals will be at minute 
// repeating every hour. 
//
// The events are to be kept in a priority queue using a heap. 
// The available gates are kept in a stick. The program should read
// exactly one input token, the token will be the number of gates.

#include <iostream>
#include <string>
#include <queue>
#include <time.h>
#include <stdlib.h>
#include <iomanip>
#include "vector"

#define MAXSIZE 50

using namespace std;

class MyStack
{
private:
     int myArray[MAXSIZE];
     int myStackTop;
	 
public:
     MyStack()
     {
        myStackTop = -1;
     }

     void Push(int data)
     {
          if (myStackTop == MAXSIZE - 1)
          {
              cout << "Stack overflow" << endl;
              // Do nothing
			  ;
          }
          //Add data
          myArray[++myStackTop] = data;
     }
     
     void Pop()
     {
          if (myStackTop == -1)
          {
              cout << "No element to remove" << endl;
             ;
          }
          //Remove data
          myStackTop--;

     }    

     int Top()
     {        
          return myArray[myStackTop];
     }     

     int IsEmpty()
     {
          if (myStackTop == -1)         
              return 1;       
          return 0;
     }   
     void Print()
     {         
          int idx1;         
          cout << "MyStack: ";          
          for (idx1 = 0; idx1 <= myStackTop; idx1++)            
              cout << myArray[idx1] << " ";         
         cout << endl;

     }
};
int main()
{
    time_t srand(time(NULL));
    priority_queue<int> queue;    
    int num;
	int dept[14];
	int flights[15] = { 1000, 1001, 1002, 1003, 1004, 1005, 1006, 1007, 1008, 1009, 1010, 1011, 1012, 1013 };
	int arrivals[14] = { 2, 3, 4, 9, 11, 14, 17, 19, 28, 33, 37, 44, 49, 55 };
	int time = 0;
	int finishTime = 1440;
	
	MyStack myGates;
	string ev1[14] = { "LAX continuing to JFK", "SMF continuing to RDU", "IAH continuing to MSP", "ABQ continuing to ATL", "SJC continuing to BOS", "PHX continuing to MIA", "SFO continuing to ORD", "SLC continuing to AUS", "TUL continuing to ONT", "DCA continuing to LAS", "BNA continuing to SEA", "MAF continuing to AMA", "HOS continuing to DEN", "ELP continuing to MEM" };  
    
//	USER PROMPT	
	cout << "Number of gates (10-40): ";    
    cin >> num;
     while (num<10 || num>40)
     {     
         cout << "Input a value from 10-40: ";       
          cin >> num;
     }
	 
     for (int idx1 = 1; idx1 <= num; idx1++)
     {     
 //	push events in queue
          queue.push(idx1);
     }   

//	Random events
     for (int idx1 = 0; idx1 < 14; idx1++)
     {
          int chances = rand() % 100 + 1;
          if (chances >= 40)
          {
              int delayTime = rand() % 40 + 20;
              dept[idx1] = arrivals[idx1] + delayTime + 60;          
          }    
		  
         else if (chances < 40)
          {      
              dept[idx1] = arrivals[idx1] + 60;
          }
     }
    cout << "<-AIRLINE->" << endl;

	cout << "GATE" << "||" << "FLIGHT" << "||" << "ARRIVAL" << "||" << "EVENT" << " ||" << "DEPARTING" << endl;

     while (time < finishTime)
     {
          time++;
          cout << "Time: " << time << endl;
          for (int idx1 = 0; idx1 < 14; idx1++)
          {
              if (!queue.empty())
              {
cout << " " << left << setw(2) << queue.top() << right << setw(2) << "||" << flights[idx1] << " ||" << setw(2) << arrivals[idx1] << " ||" << ev1[idx1] << "||" << dept[idx1] << endl;
                   queue.pop();
              }

              if (queue.empty())
              {
                   //Display message
                   cout << "<-AIRPORT FULL->" << endl;
              }
          }

          for (int idx1 = 0; idx1 < num; idx1++)
          {
              for (int j = 0; j < idx1; j++)
              {
                   if (arrivals[j] = time)
                   {
                        myGates.Push(j);                    
                        queue.pop();                
                        num--;
                   }

                   if (dept[idx1] = time)
                   {
                        myGates.Pop();
                        num++;
                   }

                   if (num == 0)
                   {
                        cout << "Airport Full" << endl;

                   }

              }

          }

     }

	 return 0;
}
				  